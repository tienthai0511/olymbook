<?php
/* 
Plugin Name: my-optin-form 
Plugin URI: olymbook.com
Description: Plugin using edit opt-in form
Author: TânTV
Version: 1.0 
Author URI: https://www.facebook.com/lonelyghost.the
*/  
ob_start();
// ---------- admin configuration page ----------
add_action( 'admin_menu', 'my_plugin_menu' );

function my_plugin_menu() {
	add_menu_page( 'My Opt-in Form Options', 'My Opt-in Form', 'manage_options', 'my-opt-in-form', 'my_optin_form_options' );
}

function my_optin_form_options() {
	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
	require_once 'my-optin-form-admin.php';
}
?>